# nyxgeek-rules
Custom rules for John the Ripper and Hashcat

2017.10.31 UPDATE
------------------------------------
Added nyxgeek-repeater-i.rule


2017.09.27 - Added a 'methodologies' folder to share methods and tricks

2017.06.08 - Separated hashcat-rules from the john-rules.  Each folder has a README with details on the rules.
