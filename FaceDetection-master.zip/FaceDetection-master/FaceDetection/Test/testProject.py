import unittest

from matplotlib import image
from matplotlib import pyplot
import pylab

class TestImage(unittest.TestCase):
    def func():
        assert False
        pyplot.matshow(self.image)
        pylab.show()

    def setUp():
        assert False
        self.image = image.imread()
