# RBF-Network
Minimal implementation of a radial basis function network.

![alt tag](https://github.com/oarriaga/RBF-Network/blob/master/result.png)
