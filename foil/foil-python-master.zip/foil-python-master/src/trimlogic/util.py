def is_tuple_or_list(x):
  return isinstance(x, tuple) or isinstance(x, list)