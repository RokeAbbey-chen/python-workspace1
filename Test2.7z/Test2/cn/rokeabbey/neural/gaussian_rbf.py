# -*- coding:utf-8 -*-
from math import exp
from math import sin
import re
import random as rd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

precision = 0.01

xrange = range

def matrix_add(m1, m2):
    # print( u'm1 = {}, m2 = {}'.format(m1, m2))
    if type(m1[0]) == list or type(m1[0]) == tuple:
        return [[m1[i][j] + m2[i][j] for j in xrange(len(m1[i]))] for i in xrange(len(m1))]
    else:
        return [m1[i] + m2[i] for i in xrange(len(m1))]


def gaussian_func(sigma_t, x, c_t):
    # print( "beta_t = {}, x = {}, c_t = {}".format(beta_t, x, c_t))
    return exp(-beta(sigma_t) * sum((x[i] - c_t[i]) ** 2 for i in xrange(len(x))))


def h(sigma_t, x, c_t):
    """计算隐层输出值"""
    return gaussian_func(sigma_t, x, c_t)


def delta_c(x, y, y_, w, sigma, c, eta):
    """
    :param x: 样本向量
    :param y: 标记向量
    :param y_: 预测结果向量
    :param w: 权重系数矩阵
    :param sigma: sigma向量
    :param c: 更新前的c矩阵
    :param eta: 学习率
    :return: delta c
    """
    # print( "x = {}, y = {}, y_ = {}, w = {}, sigma = {}, c = {}, eta = {}".format(x, y, y_, w, sigma, c, eta))
    result = list()
    for t in xrange(len(c)):
        h_t = h(sigma[t], x, c[t])
        result.append(
            [-eta * sum([(y_[j] - y[j]) * w[j][t] for j in xrange(len(y))]) * h_t * -2 * beta(sigma[t]) * (
                c[t][i] - x[i])
             for i in xrange(len(x))]
        )

    return result


def delta_w(x, y, y_, sigma, c, lmbda, w, eta):
    """
    求取w的增量
    :param x: 样本向量
    :param y:
    :param y_:
    :param sigma:
    :param c:
    :param lmbda:
    :param w:
    :param eta: 学习率
    :return:
    """
    result = [[-eta * (2 * lmbda * w[j][t] + (y_[j] - y[j]) * h(sigma[t], x, c[t])) for t in xrange(len(c))] for j in
              xrange(len(y))]
    return result


def delta_sigma(x, y, y_, sigma, c, w, eta):
    return [-eta * sum((y_[j] - y[j]) * w[j][t] for j in xrange(len(y)))
            * h(sigma[t], x, c[t]) * sum((x[i] - c[t][i]) ** 2 for i in xrange(len(x))) * 1.0 / (sigma[t] ** 3)
            for t in xrange(len(sigma))]


def beta(sigma):
    return 1.0 / (2 * sigma * sigma)


def calculate(x, w, sigma, c):
    hs = [h(sigma[t], x, c[t]) for t in xrange(len(sigma))]
    y_s = [sum(w[j][t] * hs[t] for t in xrange(len(hs))) for j in xrange(len(w))]
    return y_s


def init_c(xs, q):
    return [xs[- i - 1 + (q >> 1)] for i in xrange(q)]


def stop(mat):
    _2d = type(mat[0]) == list or type(mat[0]) == tuple
    if _2d:
        for v in mat:
            for i in v:
                if abs(i) >= precision:
                    return False
    else:
        for i in mat:
            if abs(i) >= precision:
                return False

    return True


def train(xs, ys, eta_w, eta_c, eta_b, lmbda, q=10, c1=None, sigma1=None, w1=None, limit=10000):
    """
    以单隐层rbf神经网络拟合图线
    :param xs: xs样本集合
    :param ys: 实际标记值（非0,1,而是一个实值）
    :param q: q隐含层节点数
    :return:w, c, beta 分别为权重系数，中心坐标，方差
    """
    n = len(ys[0])  # 输出层的节点数
    m = len(xs[0])  # 输入层的节点数
    c = c1 if c1 is not None else init_c(xs, q)
    sigma = sigma1 if sigma1 is not None else [1.0 for i in xrange(q)]
    w = w1 if w1 is not None else [[0.0 for j in xrange(q)] for i in xrange(n)]
    print( 'c = {}, sigma = {}, w = {}'.format(c, sigma, w))
    time = 0
    while True:
        flag = True
        if time % 100 == 0:
            print( 'time = {}'.format(time))
            print( 'c = {}, sigma = {}, w = {}'.format(c, sigma, w))

        for i in xrange(len(xs)):
            y_ = calculate(xs[i], w, sigma, c)
            dc = delta_c(xs[i], ys[i], y_, w, sigma, c, eta_c)
            ds = delta_sigma(xs[i], ys[i], y_, sigma, c, w, eta_b)
            dw = delta_w(xs[i], ys[i], y_, sigma, c, lmbda, w, eta_w)
            new_c = matrix_add(c, dc)
            new_s = matrix_add(sigma, ds)
            new_w = matrix_add(w, dw)
            c = new_c
            sigma = new_s
            w = new_w
            flag = flag and stop(dc) and stop(ds) and stop(dw)

        if flag or time >= limit:
            return c, sigma, w
        time += 1


def test(txs, tys, c, w, sigma, mx=1, mi=0):
    p = re.compile('[\[\],]')
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    y_s = [calculate(x, w, sigma, c)[0] for x in txs]
    ys = [f[0] for f in tys]
    print( '均方误差: {}'.format(cal_error_of_mean_squre(ys, y_s)))
    y_s2 = [f * (mx - mi) + mi for f in y_s]
    ys2 = [f * (mx - mi) + mi for f in ys]
    print( '均方误差2: {}'.format(cal_error_of_mean_squre(ys2, y_s2)))
    with open('test_result.dat', 'w') as f:
        for i in xrange(len(txs)):
            # print( 'before sub: {} {}'.format(txs[i], y_s[i]))
            # print( p.sub('', 'after sub: {} {}'.format(txs[i], y_s[i])))
            f.write(p.sub('', '{} {} {}\n'.format(txs[i], y_s[i], y_s2[i])))

    x1s = list()
    x0s = list()
    set(((x0s.append(x[0]), x1s.append(x[1])) for x in txs))
    ax.scatter(x0s, x1s, ys, c='b', marker='o')
    ax.scatter(x0s, x1s, y_s, c='r', marker='^')
    ax.set_xlabel('x0')
    ax.set_ylabel('x1')
    ax.set_zlabel('y')
    plt.show()
    return ax


def cal_error_of_mean_squre(ys, y_s):
    """
    计算均方误差
    :param ys:真实值
    :param y_s:预测值
    :return: 均方误差
    """
    if type(ys[0]) == list or type(ys[0]) == tuple:
        return sum([(ys[i][j] - y_s[i][j]) ** 2 for i in xrange(len(ys)) for j in xrange(len(ys[i]))]) / len(ys)
    else:
        return sum((ys[i] - y_s[i]) ** 2 for i in xrange(len(ys)))


def sigmoid_normalization(x):
    return 1.0 / (1 + exp(-x))


def main():
    choose_test_from_train = True
    p = re.compile(u'[\t ]+')
    xs = list()
    ys = list()
    txs = list()
    tys = list()
    with open('train.dat', 'r+') as f:
        for line in f:
            l = [float(s.replace('\n', '')) for s in p.split(line)]
            ys.append([l[-1]])
            del l[-1]
            xs.append(l)

    with open('test.dat', 'r+') as f:
        for line in f:
            l = [float(s.replace('\n', '')) for s in p.split(line)]
            tys.append([l[-1]])
            del l[-1]
            txs.append(l)

    print( 'xs = {}'.format(xs))
    print( 'ys = {}'.format(ys))
    print( 'txs = {}'.format(txs))
    print( 'tys = {}'.format(tys))

    c1, w1, sigma1 = None, None, None
    # c1 = [[0.18887833405139698, 0.4740235316576083], [0.275711255821293, 0.7900935432965207],
    #       [0.1786098739332994, 0.526120575838202], [0.2733697680437847, 0.693773478511109],
    #       [0.15805369995741006, 0.8210799973719392], [0.2599762487265248, 0.7346260164900407],
    #       [0.275711255821293, 0.7900935432965207], [0.1490502652827699, 0.6376072721499192],
    #       [0.10140992639073527, 0.41408148948647405], [-0.1397461604228432, 0.15465859027202367],
    #       [1.6764123982726251, 0.6441567334078631], [1.6772968833931141, 0.6479877240173427],
    #       [1.6773132377342752, 0.6480611134431052], [1.677063830396097, 0.6455709273030378],
    #       [0.6559108379675129, 0.2856504003452615], [1.6779206066953587, 0.651096950390093],
    #       [0.8223568542004696, 0.4720057257642905], [1.677967900984477, 0.6513963650689806],
    #       [1.6780220280216467, 0.6517853334864484], [0.8223568542004696, 0.4720057257642905]]
    # sigma1 = [
    #     0.04278656301139927,
    #     0.01694528523162063,
    #     0.013281771959519474,
    #     0.1156970938046128,
    #     0.0710870889801445,
    #     0.03788239571888864,
    #     0.01694528523162063,
    #     0.042045537009058505,
    #     0.021191545697393985,
    #     0.19946068897004687,
    #     0.822162577610272,
    #     0.8231863205699727,
    #     0.823205548304079,
    #     0.8227707424268,
    #     0.09149720501226043,
    #     0.8239530720228508,
    #     0.06577535901208675,
    #     0.8240179910220056,
    #     0.8240971831531019,
    #     0.06577535901208675];
    # w1 = [
    #     [-0.045565575209728995, -0.0266178088741059, 0.036077340098878245, -0.04523025341460062, 0.041167647220915746,
    #      -0.022439395701401906, -0.0266178088741059, -0.04811603371416781, -0.06827910071640989, -0.06915844106710982,
    #      0.19529256315392826, 0.19550956998394872, 0.1955136707852407, 0.19539765523816932, 0.09533327079412986,
    #      0.19567772025093813, 0.1107673850632798, 0.19569291478666104, 0.19571209603346015, 0.1107673850632798]]
    c, sigma, w = train(xs, ys, 0.1, 0.1, 0.1, 0.001, 20, c1=c1, w1=w1, sigma1=sigma1, limit=40000)

    print( "c = {}, sigma = {}, w = {}".format(c, sigma, w))
    ax = test(txs, tys, c, w, sigma, mx=1183, mi=28)


if __name__ == '__main__':
    main()
    # print( matrix_add([1, 2], [3, 4]))
    # print( matrix_add([[1, 2], [3, 4]], [[1, 2], [3, 4]]))

    # print( gaussian_func(sigma_t=10, x=[10], c_t=[3]))
    # print( h(sigma_t=10, x=[10], c_t=[3]))

    # x = [10]
    # y = [0.2]
    # y_ = [0.3]
    # w = [[1.0, 2.0, 3.5, 4.5]]
    # sigma = [3.1, 4.4, 2.3, 1.5]
    # c = [[5.5], [3.2], [3.7], [8.3]]
    # eta = 0.5
    # lmbda = 0.5
    # print( delta_c(x, y, y_, w, sigma, c, eta))
    # print( delta_w(x, y, y_, sigma, c, lmbda, w, eta))
    # print( delta_sigma(x, y, y_, sigma, c, w, eta ))
