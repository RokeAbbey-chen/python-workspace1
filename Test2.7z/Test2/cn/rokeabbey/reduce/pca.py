import numpy as np
import matplotlib.pyplot as mtp
import matplotlib.image as mpimg
gray_cofficient = np.array([0.299, 0.587, 0.114])


def rgb2gray(rgb):
    return rgb[..., :3] @ gray_cofficient


def main():
    pic = mpimg.imread('ord.jpg')
    mtp.figure(1)
    mtp.subplot(2, 2, 1)
    mtp.imshow(pic)
    gray_pic = rgb2gray(pic)
    # print(gray_pic)
    # print(gray_pic.shape)
    mtp.subplot(2, 2, 2)
    # gray_pic = np.arange(0, 255, 50)
    # gray_pic.shape = 2, 3
    mean = np.mean(gray_pic, axis=1)
    mtp.imshow(gray_pic)
    mean_gray_pic = (gray_pic.T - mean).T
    lmd, P = np.linalg.eig(mean_gray_pic @ mean_gray_pic.T)
    # abs_lmd = np.abs(lmd)
    # abs_min = abs_lmd.argmin()
    # print(abs_min, abs_lmd.argmax(), lmd[abs_min], lmd[abs_lmd.argmax()])
    # P[:, abs_min:abs_min+1] = 0
    # np.delete(P, abs_min, 1)
    # new_img = ((P.T @ mean_gray_pic).T + mean).T
    new_img = compute_pca(gray_pic)[0]
    print(gray_pic)
    print(new_img)
    # print(new_img.shape)
    mtp.subplot(2, 2, 3)
    mtp.imshow(new_img)
    mtp.show()



def compute_pca(data):
    m = np.mean(data, axis=0)
    datac = np.array([obs - m for obs in data])
    T = np.dot(datac, datac.T)
    [u,s,v] = np.linalg.svd(T)

    # here iteration is over rows but the columns are the eigenvectors of T
    pcs = [np.dot(datac.T, item) for item in u.T ]

    # note that the eigenvectors are not normed after multiplication by T^T
    # pcs = np.array([d / np.linalg.norm(d) for d in pcs])
    pcs = np.array([obs + m for obs in pcs])
    return pcs, m, s, T, u

if __name__ == '__main__':
    main()

