# Change-Detection-in-Satellite-Imagery

It employes Principal Component Analysis (PCA) and K-means clustering techniques over difference image to detect changes in multi temporal images satellite imagery.

Best thing would be to follow my blog-post for implementation. The description about how the change detection is performed on satellite imagery can be read from my blog:

https://appliedmachinelearning.wordpress.com/2017/11/25/unsupervised-changed-detection-in-multi-temporal-satellite-images-using-pca-k-means-python-code/

I have also uploaded sample images of multi-temporal pairs taken from the LANDSAT images available United States Geological Survey (USGS) website. 

It is a python implementation using Scikit-learn ML library.
