# Ripper
Python tool for splitting log file to separately files per regex rules from config.ini file.

Ripper.py is first idea to convert Perl tool rip.pl on Python platform.

Ripper_object.py is first idea to decomposing on object architecture for next development in future. 
